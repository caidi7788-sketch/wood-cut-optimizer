# 冠紳木工－板材最佳化裁切計算機

靜態 HTML 網頁工具，支援手機與電腦。首頁為 `index.html`，無需安裝套件或執行建置。

## 發布到 GitHub Pages

1. 在 GitHub 建立新的公開 repository，例如 `wood-cut-optimizer`。
2. 上傳本資料夾內的 `index.html`、`README.md`、`.nojekyll` 到儲存庫根目錄。
3. 進入 **Settings → Pages**，在 **Build and deployment** 選 **Deploy from a branch**。
4. 選擇 `main` 分支與 `/ (root)`，按 **Save**。
5. 發布完成後網址通常為 `https://你的帳號.github.io/wood-cut-optimizer/`。

注意：GitHub Pages 公開站點不適合存放私人客戶資料；請勿將存檔或施工個資提交到公開儲存庫。

## 更新

往後更新 `index.html` 並提交至 `main`，GitHub Pages 會自動重新部署。
